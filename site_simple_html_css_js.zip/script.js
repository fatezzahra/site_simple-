function direBonjour() {
    alert("Bonjour 👋 Ceci est un fichier JavaScript !");
}
